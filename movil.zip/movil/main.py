from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import pymysql
from fastapi.middleware.cors import CORSMiddleware

# Configuración de la base de datos
db_config = {
    'user': '2TsdHdB9TtPm9aP.root',
    'password': 'XegBJH4yXg81cFYQ',
    'host': 'gateway01.us-east-1.prod.aws.tidbcloud.com',
    'port': 4000,
    'database': 'test',
    'cursorclass': pymysql.cursors.DictCursor,
    'ssl': {'ssl': True}
}

# Modelos de datos
class LoginRequest(BaseModel):
    email: str
    contraseña: str

class RegisterRequest(BaseModel):
    email: str
    contraseña: str

class UpdateRequest(BaseModel):
    current_email: str
    new_email: str
    new_contraseña: str

# Inicializar FastAPI
app = FastAPI()

# Middleware CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Función para obtener conexión
def get_db_connection():
    return pymysql.connect(**db_config)

@app.get("/")
def read_root():
    return {"message": "Bienvenido a la API de usuarios usando tabla 'usuarios'"}

@app.post("/login")
def login(login_request: LoginRequest):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE email = %s AND contraseña = %s",
                   (login_request.email, login_request.contraseña))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    if user:
        return {"message": "Inicio de sesión exitoso", "user": user}
    else:
        raise HTTPException(status_code=401, detail="Credenciales inválidas")

@app.post("/register")
def register(register_request: RegisterRequest):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE email = %s", (register_request.email,))
    if cursor.fetchone():
        cursor.close()
        conn.close()
        raise HTTPException(status_code=400, detail="El correo ya está registrado")
    cursor.execute("INSERT INTO usuarios (email, contraseña) VALUES (%s, %s)",
                   (register_request.email, register_request.contraseña))
    conn.commit()
    cursor.execute("SELECT * FROM usuarios WHERE email = %s", (register_request.email,))
    new_user = cursor.fetchone()
    cursor.close()
    conn.close()
    if new_user:
        return {"message": "Registro exitoso", "user": new_user}
    else:
        raise HTTPException(status_code=500, detail="Error en el registro")

@app.delete("/delete_user/{email}")
def delete_user(email: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE email = %s", (email,))
    if not cursor.fetchone():
        cursor.close()
        conn.close()
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    cursor.execute("DELETE FROM usuarios WHERE email = %s", (email,))
    conn.commit()
    affected = cursor.rowcount
    cursor.close()
    conn.close()
    if affected > 0:
        return {"message": f"Usuario {email} eliminado correctamente"}
    else:
        raise HTTPException(status_code=500, detail="No se pudo eliminar el usuario")

@app.get("/users")
def get_all_users():
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM usuarios")
        users = cursor.fetchall()
        return {"users": users}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cursor.close()
        conn.close()

@app.put("/update_user")
def update_user(update_request: UpdateRequest):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM usuarios WHERE email = %s", (update_request.current_email,))
        if not cursor.fetchone():
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        if update_request.current_email != update_request.new_email:
            cursor.execute("SELECT * FROM usuarios WHERE email = %s", (update_request.new_email,))
            if cursor.fetchone():
                raise HTTPException(status_code=400, detail="El nuevo correo ya está en uso")
        cursor.execute("UPDATE usuarios SET email = %s, contraseña = %s WHERE email = %s",
                       (update_request.new_email, update_request.new_contraseña, update_request.current_email))
        conn.commit()
        return {"message": "Usuario actualizado correctamente"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al actualizar: {str(e)}")
    finally:
        cursor.close()
        conn.close()

# Ejecutar la aplicación
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
