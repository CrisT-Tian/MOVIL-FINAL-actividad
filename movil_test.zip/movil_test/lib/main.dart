import 'package:flutter/material.dart';
import 'pantallas/pantalla_login.dart';
import 'pantallas/pantalla_registro.dart';
import 'pantallas/pantalla_borrar.dart';
import 'pantallas/pantalla_usuarios.dart';
import 'pantallas/pantalla_actualizar.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Login con FastAPI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: Color(0xFFF3E5F5), // Lavanda claro
        primaryColor: Color(0xFFB39DDB), // Lila
        fontFamily: 'Helvetica',

        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFFB39DDB),
          foregroundColor: Colors.white,
          elevation: 2,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),

        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF512DA8), // Morado intenso
            foregroundColor: Colors.white,
            textStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            padding: EdgeInsets.symmetric(horizontal: 28, vertical: 16),
            elevation: 2,
          ),
        ),

        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          hintStyle: TextStyle(color: Colors.purple.shade200),
          labelStyle: TextStyle(color: Colors.deepPurple),
          contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Color(0xFF512DA8), width: 1.5),
          ),
        ),

        textTheme: TextTheme(
          bodyMedium: TextStyle(color: Colors.deepPurple.shade900, fontSize: 16),
          titleLarge: TextStyle(
            color: Colors.deepPurple,
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),

        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: Colors.deepPurple,
            textStyle: TextStyle(fontSize: 15),
          ),
        ),

        dividerColor: Colors.deepPurple.shade100,
        iconTheme: IconThemeData(color: Color(0xFF512DA8)),
      ),

      home: LoginScreen(),

      routes: {
        '/register': (context) => RegisterScreen(),
        '/delete_user': (context) => DeleteUserScreen(),
        '/user_list': (context) => UserListScreen(),
        '/update_user': (context) => UpdateUserScreen(),
      },
    );
  }
}
