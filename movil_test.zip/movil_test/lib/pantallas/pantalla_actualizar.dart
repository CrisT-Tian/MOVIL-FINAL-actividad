import 'package:flutter/material.dart';
import '../widgets/formulario_actualizar.dart';

class UpdateUserScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Actualizar Usuario')),
      body: SingleChildScrollView(child: UpdateUserForm()),
    );
  }
}
