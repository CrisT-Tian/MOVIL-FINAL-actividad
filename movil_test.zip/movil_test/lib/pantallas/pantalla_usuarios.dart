import 'package:flutter/material.dart';
import '../widgets/formulario_usuarios.dart';

class UserListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(body: UserList());
  }
}
